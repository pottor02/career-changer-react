
const User = () => {
    return (
        <h1>THIS IS HOME PAGE</h1>
    )
}

export default User