import React from 'react';

function App() {
  return (
    <div id="app">
      <Header />
      <Content />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    // Code here
    // <Header />
  );
}

function Content() {
  return (
    // Code here
    // <Content />
  );
}

function Temperature() {
  return (
    // Code here
    // <Temperature />
  );
}

function Footer() {
  return (
    // Code here
    // <Footer />
  );
}

export default App;
