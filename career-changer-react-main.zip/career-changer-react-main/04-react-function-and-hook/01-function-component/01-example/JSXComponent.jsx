function JSXComponent() {
    return (
        <div>
            <h1>HTML</h1>
            <h2>TAG</h2>
        </div>
    )
}

const JSXComponent = () => {
    return (
        <div>
            <h1>HTML</h1>
            <h2>TAG</h2>
        </div>
    )
}