import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div>
        <DisplayInfo />
      </div>
    );
  }
}

class DisplayInfo extends Component {
  render() {
    return (

    );
  }
}

export default App;
