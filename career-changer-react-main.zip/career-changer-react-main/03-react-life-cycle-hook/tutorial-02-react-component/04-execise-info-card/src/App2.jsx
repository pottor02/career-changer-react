import React, { Component } from 'react';
import './assets/style.css';

class App2 extends Component {

}

class DisplayInfo extends Component {

}

export default App2;
