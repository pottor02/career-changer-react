import React from 'react';

class App extends React.Component {
  render() {
    return (
      <div id="app">
        <Header />
        <Content />
        <Footer />
      </div>
    );
  }
}

// Code below!!!!

class Header extends React.Component {
  render() {
    return (
      // Code here
      // <Header />
    );
  }
}

class Content extends React.Component {
  render() {
    return (
      // Code here
      // <Content />
    );
  }
}

class Temperature extends React.Component {
  render() {
    return (
      // Code here
      // <Temperature />
    );
  }
}

class Footer extends React.Component {
  render() {
    return (
      // Code here
      // <Footer />
    );
  }
}

export default App;