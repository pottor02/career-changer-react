
const Navbar = () => {
    return (
        <ul>
            <li><a href={'/'}>Main</a></li>
            <li><a href={'/page-2'}>Page 2</a></li>
        </ul>
    )
}

export default Navbar