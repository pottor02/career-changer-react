
const Navbar = () => {
    return (
        <ul>
            <li><a href={'/'}>Main</a></li>
        </ul>
    )
}

export default Navbar