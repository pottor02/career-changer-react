import { useState } from 'react'
import Layout from './Layout'

const App = () => {
    
    return (
        <Layout>
            <div>
                Application
            </div>
        </Layout>
    )
}

export default App

