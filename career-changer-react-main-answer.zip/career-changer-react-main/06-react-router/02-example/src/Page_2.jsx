import Layout from './Layout'

const Page2 = () => {
    return (
        <Layout>
            <div>
                Page 2
            </div>
        </Layout>
    )
}

export default Page2