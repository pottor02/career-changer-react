export function getTemp() {
    const temperature = (Math.random() * 100)
    return temperature
}